package com.jikexueyuan.simplecalculator2017;

/**
 * Created by stan on 2017/3/23.
 */

public class Types {

    public static final int plus = 1;
    public static final int minus = 2;
    public static final int multiply = 3;
    public static final int divide = 4;
    public static final int num = 5;
}
