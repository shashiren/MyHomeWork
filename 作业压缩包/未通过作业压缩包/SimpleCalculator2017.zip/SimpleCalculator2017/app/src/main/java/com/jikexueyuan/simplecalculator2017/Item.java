package com.jikexueyuan.simplecalculator2017;

/**
 * Created by stan on 2017/3/23.
 */

public class Item {

    public Item(double value, int type  ) {
        this.value = value;
        this.type = type;

    }

    public double value = 0;
    public int type = 0;

}
