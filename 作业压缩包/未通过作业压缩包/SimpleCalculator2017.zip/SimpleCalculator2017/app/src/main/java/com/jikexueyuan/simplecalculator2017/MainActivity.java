package com.jikexueyuan.simplecalculator2017;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    private List<Item> items = new ArrayList<Item>();
    private EditText et_input;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.btn_0).setOnClickListener(this);
        findViewById(R.id.btn_1).setOnClickListener(this);
        findViewById(R.id.btn_2).setOnClickListener(this);
        findViewById(R.id.btn_3).setOnClickListener(this);
        findViewById(R.id.btn_4).setOnClickListener(this);
        findViewById(R.id.btn_5).setOnClickListener(this);
        findViewById(R.id.btn_6).setOnClickListener(this);
        findViewById(R.id.btn_7).setOnClickListener(this);
        findViewById(R.id.btn_8).setOnClickListener(this);
        findViewById(R.id.btn_9).setOnClickListener(this);
        findViewById(R.id.btn_plus).setOnClickListener(this);
        findViewById(R.id.btn_minus).setOnClickListener(this);
        findViewById(R.id.btn_multiply).setOnClickListener(this);
        findViewById(R.id.btn_divide).setOnClickListener(this);
        findViewById(R.id.btn_c).setOnClickListener(this);
        findViewById(R.id.btn_equal).setOnClickListener(this);



        et_input = (EditText) findViewById(R.id.et_input);  //实例化之后的显示屏




    }
//

    @Override
    public void onClick(View view) {
//        String str = et_input.getText().toString();

//        double b = items.get(2).value;
        switch (view.getId()) {
            case R.id.btn_0:
                et_input.append("0");
                break;
            case R.id.btn_1:
                et_input.append("1");
                break;
            case R.id.btn_2:
                et_input.append("2");
                break;
            case R.id.btn_3:
                et_input.append("3");
                break;
            case R.id.btn_4:
                et_input.append("4");
                break;
            case R.id.btn_5:
                et_input.append("5");
                break;
            case R.id.btn_6:
                et_input.append("6");
                break;
            case R.id.btn_7:
                et_input.append("7");
                break;
            case R.id.btn_8:
                et_input.append("8");
                break;
            case R.id.btn_9:
                et_input.append("9");
                break;
            case R.id.btn_plus:
               items.add(new Item(Double.parseDouble(et_input.getText().toString()),Types.num));
                checkAndCompute();
                items.add(new Item(0,Types.plus));
                et_input.setText("");
                break;


            case R.id.btn_minus:
                items.add(new Item(Double.parseDouble(et_input.getText().toString()),Types.num));
                checkAndCompute();
                items.add(new Item(0,Types.minus));
                et_input.setText("");
                break;

            case R.id.btn_multiply:

                items.add(new Item(Double.parseDouble(et_input.getText().toString()),Types.num));
                checkAndCompute();
                items.add(new Item(0,Types.multiply));
                et_input.setText("");
                break;
            case R.id.btn_divide:

                items.add(new Item(Double.parseDouble(et_input.getText().toString()),Types.num));
                checkAndCompute();
                items.add(new Item(0,Types.divide));
                et_input.setText("");

                break;

            case R.id.btn_c:

                et_input.setText("");
                items.clear();
                break;
            case R.id.btn_equal:
                items.add(new Item(Double.parseDouble(et_input.getText().toString()),Types.num));
                checkAndCompute();
                et_input.setText(items.get(0).value+"");
                items.clear();
                break;


        }


    }
//    实现加减乘除运算

    public void checkAndCompute(){
        if (items.size()>=3) {

            double a = items.get(0).value;
            double b = items.get(2).value;
            int opt = items.get(1).type;
            Toast tipsToast = Toast.makeText(MainActivity.this,"被除数不能为0",Toast.LENGTH_LONG);
            tipsToast.setGravity(Gravity.CENTER,0,0);

            items.clear();


            switch (opt) {
                case Types.plus:
                    items.add(new Item(a + b, Types.num));

                    break;
                case Types.minus:
                    items.add(new Item(a - b, Types.num));

                    break;
                case Types.multiply:

                    items.add(new Item(a * b, Types.num));
                    break;
                case Types.divide:

                    items.add(new Item(a / b, Types.num));

                    break;
            }
        }
    }


}
