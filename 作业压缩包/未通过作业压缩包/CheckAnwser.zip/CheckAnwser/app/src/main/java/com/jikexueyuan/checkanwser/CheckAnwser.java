package com.jikexueyuan.checkanwser;

import android.icu.util.IslamicCalendar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.TextView;


public class CheckAnwser extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {
    private Button btnSubmit;
    private RadioButton rbA;
    private RadioButton rbB;
    private CheckBox checkbox1,checkbox2,checkbox3,checkbox4,checkbox5,checkbox6;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.checkanwser);

        btnSubmit = (Button) findViewById(R.id.btnSubmit);
        rbA = (RadioButton) findViewById(R.id.rbA);
        rbB = (RadioButton) findViewById(R.id.rbB);

        tvResult = (TextView) findViewById(R.id.tvResult);

        checkbox1 = (CheckBox) findViewById(R.id.checkbox1);
        checkbox2 = (CheckBox) findViewById(R.id.checkbox2);
        checkbox3 = (CheckBox) findViewById(R.id.checkbox3);
        checkbox4 = (CheckBox) findViewById(R.id.checkbox4);
        checkbox5 = (CheckBox) findViewById(R.id.checkbox5);
        checkbox6 = (CheckBox) findViewById(R.id.checkbox6);

        checkbox1.setOnCheckedChangeListener(this);
        checkbox2.setOnCheckedChangeListener(this);
        checkbox3.setOnCheckedChangeListener(this);
        checkbox4.setOnCheckedChangeListener(this);
        checkbox5.setOnCheckedChangeListener(this);
        checkbox6.setOnCheckedChangeListener(this);



        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str = getString(R.string.str);
                String str1 = getString(R.string.str1);
                String str2 = getString(R.string.str2);
                String str3 = getString(R.string.str3);

                if (rbA.isChecked()&&checkbox3.isChecked()&&checkbox6.isChecked()&&!checkbox1.isChecked()&&!checkbox2.isChecked()&&!checkbox4.isChecked()&&!checkbox5.isChecked()){
                    str+=rbA.getText()+","+str1;
                    tvResult.setText(str);
                }else if (rbA.isChecked()){
                    str+=rbA.getText()+","+str2;
                    tvResult.setText(str);
                }else if (rbB.isChecked()&&checkbox3.isChecked()&&checkbox6.isChecked()&&!checkbox1.isChecked()&&!checkbox2.isChecked()&&!checkbox4.isChecked()&&!checkbox5.isChecked()){
                    str+=rbB.getText()+","+str1;
                    tvResult.setText(str);
                } else if (rbB.isChecked()){
                    str+=rbB.getText()+","+str2;
                    tvResult.setText(str);
                } else if (checkbox3.isChecked()&&checkbox6.isChecked()&&!checkbox1.isChecked()&&!checkbox2.isChecked()&&!checkbox4.isChecked()&&!checkbox5.isChecked()){
                    str3+=","+str1;
                    tvResult.setText(str3);
                }
                else {
                    str3+=","+str2;
                    tvResult.setText(str3);
                };





            }
        });
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {


    }
}
